<!--**************************************************-->
<!-----------------IBOTTOM STARTS----------------------->
<!--**************************************************-->
<div class="container-fluid fluid0 py-4">
 <div id="footercontent">
  <footer>
   <div class="container container0">
    <div class="row px-0 mx-0">   
     <div class="col-xs-12 col-sm float-left text-left">
      <? $year=date("Y");?><font class="icopyright">&#169;&nbsp;Copyright&nbsp;<?echo $year?>All rights reserved.</font>
      </div>
      <div class="col-xs-12 col-sm float-sm-right text-sm-right">
       <font class="idesign">design by</font>
       <img width="16" height="20" border="0" src="webimg/logo.png">
       <a target="_blank" href="http://www.imitpark.com"><font class="idesign">www.imitpark.com</font></a>
      </div>
     </div>
    </div>
   </footer>
  </div>
 </div>
<!--***************************************************-->
<!---------------------IBOTTOM ENDS----------------------->
<!--****************************************************-->
</body>
</html>