<?//ini_set('error_reporting', 0);
//ini_set('display_errors', 0);?>
<? session_start(); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
 <head>
  <title><? include ("ititle.php") ?></title>
  <!----dont touch starts----><? include ("iheadscripts.php") ?><!----dont touch starts---->
  <? include ("iheadotherscripts.php") ?>
 </head>
<?$scriptname=  $_SERVER['SCRIPT_NAME'];
$spscriptname=preg_split('[/]',$scriptname); 
$arrno=count($spscriptname);
$arr=$arrno-1;
$fname= $spscriptname[$arr];?>
 <body>