<? include ("itophead.php") ?>
<?
if($fname=="index.php"){$ho="active";}
if($fname=="aboutus.php"){$ab="active";}
if($fname=="services.php"){$ser="active";}
if($fname=="experience.php"){$exp="active";}
if($fname=="contactus.php"){$co="active";}
?>
<!-------------------------------***********************************----------------------------------->
<!---------------------------------------LARGE SCREEN TOP START------------------------------------------>
<!-------------------------------************************************----------------------------------->
<div class="container-fluid fluid0 bg-white d-none d-sm-none d-md-block">
 <div class="header py-3" id="header">
  <div class="container">
   <div class="text-right d-none d-md-block col-12 fluid0">   
    <i class="fab fa1 fa-lg fa-facebook-f mr-2 rounded-circle"></i>
    <i class="fab fa1 fa-lg fa-twitter mr-2 rounded-circle"></i>
    <i class="fab fa-lg fa1 fa-instagram mr-2 rounded-circle"></i>	 
    <img src="webimg/img.jpg"class="mr-1"><font class="toptxt">EMAIL :<a class="toptxt" href="mailto: info@dummy.com?subject=Enquiry from  www.dummy.com" class="temail">&nbsp;info@dummy.com</a></font>
   <img src="webimg/img.jpg"class="mr-1"><font class="toptxt">CALL US ON :<span class="toptxtsub mr-2">+971 0 000 000</span></font>	     
   </div>
   <div class="row mx-0 px-0" >    
<!---------------------------------- LOGO FOR LARGE SCREEN START --------------------------------------->
<!------------------------------------------------------------------------------------------------------>
    <div class="d-none d-md-block col-md-12 col-lg-3 col-xl-3 px-0">
     <?if($fname=="index.php" ){?>
      <img src="webimg/logo.jpg" class="img-fluid float-left d-md-none d-lg-block logo">
     <?}else{?>
      <a href="index.php"><img src="webimg/logo.jpg" class="img-fluid float-left d-md-none d-lg-block logo"></a>
     <?}?>
     <?if($fname=="index.php" ){?>
      <img src="webimg/logo.jpg" class="img-fluid mx-auto mt-3 d-none d-md-block d-lg-none logo" >
     <?}else{?>
      <a href="index.php"><img src="webimg/logo.jpg" class="img-fluid mt-3 mx-auto d-none d-md-block d-lg-none logo" ></a>
     <?}?>
    </div>	
<!----------------------------------- LOGO FOR LARGE SCREEN ENDS ---------------------------------------->   
<!--------------------------------------- NAVBAR DIV START----------------------------------------------->
    <div class="col-md-12 col-lg-9 col-xl-9 fluid0">  
     <div class="col-12 px-0">	  
      <ul class="nav justify-content-md-center justify-content-lg-end">
<!-------------------------------------- NAVBAR LINKS START --------------------------------------------->
      <?if($fname=="index.php" ){?>
       <li class="nav-item" style="padding-left:0px;"><a class="nav-link <? echo $ho;?>">Home</a></li>
      <?}else{?>
       <li class="nav-item" style="padding-left:0px;"><a class="nav-link" href="index.php">Home</a></li>
      <?}?>
      <?if($fname=="aboutus.php" ){?>
       <li class="nav-item"><a class="nav-link <? echo $ab;?>">About us</a></li>
      <?}else{?>
       <li class="nav-item"><a class="nav-link" href="aboutus.php">About us</a></li>
      <?}?>			
      <li class="nav-item dropdown dropdown-toggle" data-toggle="dropdown">
       <a class="nav-link ">Dropdown</a>
        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
         <a class="dropdown-item" href="#">Action</a>
         <a class="dropdown-item" href="#">Another action</a>
         <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </li>
      <?if($fname=="services.php" ){?>
       <li class="nav-item"><a class="nav-link <? echo $ser;?>">Our Services </a></li>
      <?}else{?>
       <li class="nav-item"><a class="nav-link" href="services.php">Our Services </a></li>
      <?}?>
      <?if($fname=="experience.php" ){?>
       <li class="nav-item"><a class="nav-link <? echo $exp;?>">Experience</a></li>
      <?}else{?>
       <li class="nav-item"><a class="nav-link" href="experience.php">Experience</a></li>
      <?}?>
      <?if($fname=="contactus.php" ){?>
       <li class="nav-item" style="padding-right:0px;"><a class="nav-link <? echo $co;?>">Contact Us</a></li>
      <?}else{?>
       <li class="nav-item" style="padding-right:0px;"><a class="nav-link" href="contactus.php">Contact Us</a></li>
      <?}?>
<!----------------------------------------- NAVBAR LINKS ENDS ------------------------------------------>
      </ul>		  	
     </div>
    </div>
<!----------------------------------------- NAVBAR DIV ENDS---------------------------------------------->
   </div>
  </div>
 </div>
</div>
<!------------------------------- ********************************** ------------------------------------>
<!---------------------------------------LARGE SCREEN TOP ENDS------------------------------------------->
<!-------------------------------*************************************------------------------------------>
<!---------===================================================================================== -------->
<!------------------------------- ************************************* ------------------------------------>
<!-----------------------------------SMALL SCREEN SIDE MENU STARTS--------------------------------------->
<!------------------------------- ************************************* ------------------------------------>
<div class="container-fluid fluid0 bodybg d-block d-md-none">
 <div class="header" id="header">
  <div class="container container0">
   <? include ("mobtop.php") ?>
  </div>
 </div>
</div>
<!------------------------------- ************************************* ------------------------------------>
<!-----------------------------------SMALL SCREEN SIDE MENU ENDS----------------------------------------->
<!------------------------------- ************************************* ------------------------------------>