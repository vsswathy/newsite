<?
$mainheading="PRODUCT LIST";
?>
<? include ("itop.php") ?>
<!------------------------------------ INNER BANNER START ----------------------------------->
<div class="row fluid0">
 <div class="col-12 fluid0">
  <? include ("innerbanner.php") ?>
 </div>
</div>
<!------------------------------------ INNER BANNER ENDS ------------------------------------->
<!------------------------------------ INNER PAGE CONTENTS START ----------------------------->
<div class="container-fluid fluid0 bodywhite py-4">
 <div  id="productlist">
  <div class="container container0">
   <div class="col-12 col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
    <div class="row mx-0">
	 <div class="card-deck">
	 <!----================================================================------->
	 <!----***********************PRODUCT1 STARTS**************************------->
	 <!----================================================================------->	  
	  <div class="card rounded-0 mb-4">
	   <div class="card-body"><img class="card-img-top " src="webimg/101.jpg" alt="Card image cap"></div>
	   <div class="card-body pt-0">
	    <h5 class="card-title">Product Name</h5>	     
		 <table class="table table-borderless card-text">
		  <tbody>
			<tr>
			  <td width="45%">Product Code</td>
			  <td width="5%" class="px-2">:</td>
			  <td width="50%">ABCD</td>			 
			</tr>
			<tr>
			  <td width="45%">Brand</td>
			  <td width="5%" class="px-2">:</td>
			  <td width="50%">Brand Name</td>
			</tr>
			<tr>
			  <td width="45%">Stock Available</td>
			  <td width="5%" class="px-2">:</td>
			  <td width="50%">10</td>
			</tr>
		  </tbody>
		 </table>
	     <a href="#" class="btn btn-primary rounded-0 mt-2 mr-1">View Details</a>
		 <a href="#" class="mt-2 btn btn-primary rounded-0 float-right">BRAND</a>
	   </div>
	  </div>
	 <!----================================================================------->
	 <!----***********************PRODUCT1 ENDS**************************--------->
	 <!----================================================================------->		   
	 <!----================================================================------->
	 <!----***********************PRODUCT2 STARTS**************************------->
	 <!----================================================================------->	  
	  <div class="card rounded-0 mb-4">
	   <div class="card-body"><img class="card-img-top " src="webimg/102.jpg" alt="Card image cap"></div>
	    <div class="card-body pt-0">
	     <h5 class="card-title">Product Name</h5>
		 <table class="table table-borderless card-text">
		  <tbody>
			<tr>
			  <td width="45%">Product Code</td>
			  <td width="5%" class="px-2">:</td>
			  <td width="50%">ABCD</td>			 
			</tr>
			<tr>
			  <td width="45%">Brand</td>
			  <td width="5%" class="px-2">:</td>
			  <td width="50%">Brand Name</td>
			</tr>
			<tr>
			  <td width="45%">Stock Available</td>
			  <td width="5%" class="px-2">:</td>
			  <td width="50%">10</td>
			</tr>
		  </tbody>
		 </table>
	     <a href="#" class="btn btn-primary rounded-0 mt-2 mr-1">View Details</a>
		 <a href="#" class="mt-2 btn btn-primary rounded-0 float-right">BRAND</a>
	   </div>
	  </div>
	 <!----================================================================------->
	 <!----***********************PRODUCT2 ENDS**************************--------->
	 <!----================================================================------->		   	   
	 <!----================================================================------->
	 <!----***********************PRODUCT3 STARTS**************************------->
	 <!----================================================================------->	  
	  <div class="card rounded-0 mb-4">
	   <div class="card-body"><img class="card-img-top " src="webimg/103.jpg" alt="Card image cap"></div>
	    <div class="card-body pt-0">
	     <h5 class="card-title">Product Name</h5>
		 <table class="table table-borderless card-text">
		  <tbody>
			<tr>
			  <td width="45%">Product Code</td>
			  <td width="5%" class="px-2">:</td>
			  <td width="50%">ABCD</td>			 
			</tr>
			<tr>
			  <td width="45%">Brand</td>
			  <td width="5%" class="px-2">:</td>
			  <td width="50%">Brand Name</td>
			</tr>
			<tr>
			  <td width="45%">Stock Available</td>
			  <td width="5%" class="px-2">:</td>
			  <td width="50%">10</td>
			</tr>
		  </tbody>
		 </table>
	     <a href="#" class="btn btn-primary rounded-0 mt-2 mr-1">View Details</a>
		 <a href="#" class="mt-2 btn btn-primary rounded-0 float-right">BRAND</a>
	   </div>
	  </div>
	 <!----================================================================------->
	 <!----***********************PRODUCT3 ENDS**************************--------->
	 <!----================================================================------->	
	 <!----================================================================------->
	 <!----***********************PRODUCT4 STARTS**************************------->
	 <!----================================================================------->	  
	  <div class="card rounded-0 mb-4">
	   <div class="card-body"><img class="card-img-top " src="webimg/104.jpg" alt="Card image cap"></div>
	    <div class="card-body pt-0">
	     <h5 class="card-title">Product Name</h5>
		 <table class="table table-borderless card-text">
		  <tbody>
			<tr>
			  <td width="45%">Product Code</td>
			  <td width="5%" class="px-2">:</td>
			  <td width="50%">ABCD</td>			 
			</tr>
			<tr>
			  <td width="45%">Brand</td>
			  <td width="5%" class="px-2">:</td>
			  <td width="50%">Brand Name</td>
			</tr>
			<tr>
			  <td width="45%">Stock Available</td>
			  <td width="5%" class="px-2">:</td>
			  <td width="50%">10</td>
			</tr>
		  </tbody>
		 </table>
	     <a href="#" class="btn btn-primary rounded-0 mt-2 mr-1">View Details</a>
		 <a href="#" class="mt-2 btn btn-primary rounded-0 float-right">BRAND</a>
	   </div>
	  </div>
	 <!----================================================================------->
	 <!----***********************PRODUCT4 ENDS**************************--------->
	 <!----================================================================------->	
	 <!----================================================================------->
	 <!----***********************PRODUCT5 STARTS**************************------->
	 <!----================================================================------->	  
	  <div class="card rounded-0 mb-4">
	   <div class="card-body"><img class="card-img-top " src="webimg/105.jpg" alt="Card image cap"></div>
	    <div class="card-body pt-0">
	     <h5 class="card-title">Product Name</h5>
		 <table class="table table-borderless card-text">
		  <tbody>
			<tr>
			  <td width="45%">Product Code</td>
			  <td width="5%" class="px-2">:</td>
			  <td width="50%">ABCD</td>			 
			</tr>
			<tr>
			  <td width="45%">Brand</td>
			  <td width="5%" class="px-2">:</td>
			  <td width="50%">Brand Name</td>
			</tr>
			<tr>
			  <td width="45%">Stock Available</td>
			  <td width="5%" class="px-2">:</td>
			  <td width="50%">10</td>
			</tr>
		  </tbody>
		 </table>
	     <a href="#" class="btn btn-primary rounded-0 mt-2 mr-1">View Details</a>
		 <a href="#" class="mt-2 btn btn-primary rounded-0 float-right">BRAND</a>
	   </div>
	  </div>
	 <!----================================================================------->
	 <!----***********************PRODUCT5 ENDS**************************--------->
	 <!----================================================================------->	
	 <!----================================================================------->
	 <!----***********************PRODUCT6 STARTS**************************------->
	 <!----================================================================------->	  
	  <div class="card rounded-0 mb-4">
	   <div class="card-body"><img class="card-img-top " src="webimg/106.jpg" alt="Card image cap"></div>
	    <div class="card-body pt-0">
	     <h5 class="card-title">Product Name</h5>
		 <table class="table table-borderless card-text">
		  <tbody>
			<tr>
			  <td width="45%">Product Code</td>
			  <td width="5%" class="px-2">:</td>
			  <td width="50%">ABCD</td>			 
			</tr>
			<tr>
			  <td width="45%">Brand</td>
			  <td width="5%" class="px-2">:</td>
			  <td width="50%">Brand Name</td>
			</tr>
			<tr>
			  <td width="45%">Stock Available</td>
			  <td width="5%" class="px-2">:</td>
			  <td width="50%">10</td>
			</tr>
		  </tbody>
		 </table>
	     <a href="#" class="btn btn-primary rounded-0 mt-2 mr-1">View Details</a>
		 <a href="#" class="mt-2 btn btn-primary rounded-0 float-right">BRAND</a>
	   </div>
	  </div>
	 <!----================================================================------->
	 <!----***********************PRODUCT6 ENDS**************************--------->
	 <!----================================================================------->		 
	 </div>	  	 
    </div>
   </div>
  </div>
 </div>
</div>
<style>
.card-deck .card .table td, .card-deck .card  .table th {
     padding-right: 0px; 
	 padding-left: 0px; 
	 padding-top: 0px;
	 padding-bottom: 8px!important; 
}
.card-deck .card .table {     
	 margin-bottom: 0px!important; 
}
@media (min-width: 576px) {
  .card-deck .card {
		flex: 0 0 calc(50% - 30px);
  }
}
@media (min-width: 768px) {
	.card-deck .card {
		flex: 0 0 calc(50% - 30px);
	}
}
@media (min-width: 992px) {
	.card-deck .card {
		flex: 0 0 calc(33.3333333333% - 30px);
	}
}
@media (min-width: 1200px) {
	.card-deck .card {
		flex: 0 0 calc(25% - 30px);
	}
}
.card-title{
	color:#000;
}
.card-text{
	color:#000;
}
.card-body {  
    padding: .90rem!important;
}
</style>
<!------------------------------------- INNER PAGE CONTENTS ENDS ------------------------------>
<? include ("ibottom.php") ?>