<!----------For inner banner cut and paste on top start-----------------<div class="row fluid0"> <div class="col-12  fluid0">  <?// include ("innerbanner.php") ?> </div></div><!-------For inner banner cut and paste on top on top end---------------><?
if($fname=="aboutus.php"){
	$ban="innerbanner01.jpg";
	$banm="minnerbanner01.jpg";
}if($fname=="services.php"){	$ban="innerbanner02.jpg";	$banm="minnerbanner02.jpg";}if($fname=="contactus.php"){	$ban="innerbanner03.jpg";	$banm="minnerbanner03.jpg";}
?>
<div class="container-fluid fluid0 d-none d-md-block">
  <div id="innerbanner"><img src="webimg/<?echo $ban;?>" width="100%;"></div>
</div>
<div class="container-fluid fluid0 d-md-none ">
  <div id="innerbannerm"><img src="webimg/<?echo $banm;?>" width="100%;"></div>
</div>