<link href="css/darkbox.css" rel="stylesheet" type="text/css">
<script src="js/darkbox.js"></script>

<div class="col-12 flouid0">
 <img src="webimg/<?echo $pimg;?>" data-darkbox="webimg/<?echo $pimg;?>"  data-darkbox-group="one">
</div>