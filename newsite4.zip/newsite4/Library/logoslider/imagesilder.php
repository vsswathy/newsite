<link rel="stylesheet" href="css/jquerysctipttop.css">
<script src="js/jquery.imageslider.js"></script>
<script>
 $(function() {
  $('.js-imageslider').imageslider({
   slideItems: '.my-slider-item',
   slideContainer: '.my-slider-list',
   slideDistance: 1,
   slideDuratin:500,
   resizable: false,
   pause: true
  });
 });
</script>
<!--------------------------.....................................................--------------------------------->
<!--------------------------------------IMAGE SLIDER STARTS------------------------------------------------------->
<!--------------------------.....................................................--------------------------------->
<div class="container-fluid fluid0 hide_me">
 <div  id="service">
  <div class="container">
   <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 fluid0">
    <div class="col-xs-12 service">
     <div class="my-slider js-imageslider">
      <ul class="my-slider-list">
	  <!-----------------------IMAGE1 STARTS-------------------->
	   <li class="my-slider-item">	
	    <div id="itemset">
	     <a href="services.php">
	      <img src="webimg/logo1.jpg" class="img-responsive">		
	     </a>		
	    </div>
	   </li>
	   <!-----------------------IMAGE1 ENDS---------------------->
	   <!-----------------------IMAGE2 STARTS-------------------->
	   <li class="my-slider-item">	
	    <div id="itemset">
	     <a href="services.php">
	      <img src="webimg/logo2.jpg" class="img-responsive">
	     </a>		
	    </div>
	   </li>
	   <!-----------------------IMAGE2 ENDS---------------------->
	   <!-----------------------IMAGE3 STARTS-------------------->
	   <li class="my-slider-item">	
	    <div id="itemset">
	     <a href="services.php">
	      <img src="webimg/logo3.jpg" class="img-responsive">
	     </a>		
	    </div>
	   </li>
	   <!-----------------------IMAGE3 ENDS---------------------->
	   <!-----------------------IMAGE4 STARTS-------------------->
	   <li class="my-slider-item">	
	    <div id="itemset">
	     <a href="services.php">
	      <img src="webimg/logo3.jpg" class="img-responsive">
	     </a>		
	    </div>
	   </li>
	   <!-----------------------IMAGE4 ENDS---------------------->
	   <!-----------------------IMAGE5 STARTS-------------------->
	   <li class="my-slider-item">	
	    <div id="itemset">
	     <a href="services.php">
	      <img src="webimg/logo3.jpg" class="img-responsive">
	     </a>		
	    </div>
	   </li>
	   <!-----------------------IMAGE5 ENDS---------------------->
	   <!-----------------------IMAGE6 STARTS-------------------->
	   <li class="my-slider-item">	
	    <div id="itemset">
	     <a href="services.php">
	      <img src="webimg/logo3.jpg" class="img-responsive">
	     </a>		
	    </div>
	   </li>
	   <!-----------------------IMAGE6 ENDS---------------------->
	   <!-----------------------IMAGE7 STARTS-------------------->
	   <li class="my-slider-item">	
	    <div id="itemset">
	     <a href="services.php">
	      <img src="webimg/logo3.jpg" class="img-responsive">
	     </a>		
	    </div>
	   </li>
	   <!-----------------------IMAGE7 ENDS---------------------->
	   <!-----------------------IMAGE8 STARTS-------------------->
	   <li class="my-slider-item">	
	    <div id="itemset">
	     <a href="services.php">
	      <img src="webimg/logo3.jpg" class="img-responsive">
	     </a>		
	    </div>
	   </li>
	   <!-----------------------IMAGE8 ENDS---------------------->
<!------------------------Repeating Set--------------------------------->	
	  
<!------------------------Repeating Set ends---------------------------->						
      </ul>
     </div> 
    </div>
   </div>
  </div> 
 </div> 
</div>
<!--------------------------.....................................................--------------------------------->
<!--------------------------------------IMAGE SLIDER ENDS--------------------------------------------------------->
<!--------------------------.....................................................--------------------------------->

<!---------------------------IMAGE SLIDER STYLE STARTS MOVE TO STYLE PAGE-------------------->
<style type="text/css">
	.my-slider {
		margin: 0 auto;
	}
	.my-slider ul {
		height: auto;
		overflow: hidden;
		margin-bottom: 0;
	}
	.my-slider li {
		float: left;
		list-style: none;	   
	}
	.my-slider li #descset {
		margin: 0 15px;
	}
	#itemset{
		position:relative;
		height:411px;
		width:360px;
		margin-left:15px!important;
		margin-right:15px!important;	
	}
	#itemset h3{
		font-size:18px;
		font-family: 'latobold';
		color:#ffffff;
	}
</style>
<!---------------------------IMAGE SLIDER STYLE ENDS MOVE TO STYLE PAGE-------------------->
