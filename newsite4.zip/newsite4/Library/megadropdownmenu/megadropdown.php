<!-------------------------------*************************---------------------------------------------->
<!-------------------------------MEGA DROPDOWN MENU STARTS---------------------------------------------->
<!-------------------------------*************************---------------------------------------------->

<li class="dropdown mega-dropdown hidden-xs hidden-sm "><!-------- FOR LARGE SCREEN AND MD SCREEN-------------->
 <a class="dropdown-toggle " data-toggle="dropdown" href="productlist.php">Products<span class="caret"></span></a><!--CHANGE THE LINK TO THE PAGE------------>
 <!------------------DROPDOWN STARTS--------------------->
 <ul class="dropdown-menu mega-dropdown-menu container1 "style="border-bottom: 6px solid #000; background-color:#f3f3f3;">
 <!--------------COLUMN1 STARTS------------------------->
  <li class="col-sm-6 col-md-3 col-lg-3">
   <ul>
    <li><a href="productlist.php">Dummytxt</a></li>
	<li><a >Dummytxt</a></li>
	<li><a >Dummytxt</a></li>
	<li><a >Dummytxt</a></li>
	<li><a >Dummytxt</a></li>
	<li><a >Dummytxt</a></li>
	<li><a >Dummytxt</a></li>
	<li><a >Dummytxt</a></li>
   </ul>
  </li>
  <!--------------COLUMN1 ENDS------------------------->
  <!--------------COLUMN2 STARTS------------------------->
  <li class="col-sm-6 col-md-3 col-lg-3">
   <ul>
    <li><a >Dummytxt</a></li>
    <li><a >Dummytxt</a></li>
    <li><a >Dummytxt</a></li>
    <li><a >Dummytxt</a></li>
	<li><a >Dummytxt</a></li>
	<li><a >Dummytxt</a></li>
	<li><a >Dummytxt</a></li>
	<li><a >Dummytxt</a></li>
   </ul>
  </li>
  <!--------------COLUMN2 ENDS------------------------->
  <!--------------COLUMN3 STARTS------------------------->
  <li class="col-sm-6 col-md-3 col-lg-3">
   <ul>	
    <li><a >Dummytxt</a></li>
    <li><a >Dummytxt</a></li>
	<li><a >Dummytxt</a></li>
    <li><a >Dummytxt</a></li>
	<li><a >Dummytxt</a></li>
	<li><a >Dummytxt</a></li>
	<li><a >Dummytxt</a></li>
	<li><a >Dummytxt</a></li>
   </ul>
  </li>
  <!--------------COLUMN3 ENDS------------------------->
  <!--------------COLUMN4 STARTS------------------------->
  <li class="col-sm-6 col-md-3 col-lg-3">
   <ul>
	<li><a >Dummytxt</a></li>
	<li><a >Dummytxt</a></li>
	<li><a >Dummytxt</a></li>
	<li><a >Dummytxt</a></li>
	<li><a >Dummytxt</a></li>
	<li><a >Dummytxt</a></li>
	<li><a >Dummytxt</a></li>
   </ul>
  </li>
  <!--------------COLUMN4 ENDS------------------------->
 </ul>		
<!-----------------------------DROPDOWN ENDS-----------------> 
</li>
<!------------------------------- *********************** ------------------------------------------------->
<!------------------------------- MEGA DROPDOWN MENU ENS  ---------------------------------------------->
<!------------------------------- *********************** ---------------------------------------------->
<!------------------------------- ................................. -------------------------------------->
<!------------------------------- MEGA DROPDOWN MENU  SCRIPT STARTS -------------------------------------->
<!-------------------------------- ................................ ---------------------------------->
<script>
$(document).ready(function(){
    $(".dropdown").hover(            
        function() {
            $('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideDown("400");
            $(this).toggleClass('open');        
        },
        function() {
            $('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideUp("400");
            $(this).toggleClass('open');       
        }
    );
});
</script>
<!----------------------------- ................................ ----------------------------->
<!----------------------------- MEGA DROPDOWN MENU  SCRIPT ENDS  ----------------------------->
<!----------------------------- ................................ ------------------------------>
<!---******************************** STYLE MEGHA MENU START move to style.css*****************---->
<style>
.dropdown-menu {
    top: none;
	}
.mega-dropdown {
  position: static !important;
}
.mega-dropdown-menu {
    padding: 20px 0px;
    box-shadow: none;
    -webkit-box-shadow: none;
}
.navbar-nav>li>.dropdown-menu {
    margin-top: 0;
    border-top-left-radius: 0;
    border-top-right-radius: 0;
    padding-left: 10px;
    padding-right: 10px;
}
.mega-dropdown-menu > li > ul {
  padding: 0;
  margin: 0;
}
.mega-dropdown-menu > li > ul > li {
  list-style-image:url('webimg/arwpro1.png');
  margin-left: 10px;
}
.mega-dropdown-menu > li > ul > li:hover {
 color:#E61D25!important;
}
.mega-dropdown-menu > li > ul > li > a {
  display: block;
    font-family: 'RobotoRegular';
  padding:3px 0px;
  font-size:17px;
  color: #333;
}
.mega-dropdown-menu > li ul > li > a:hover,
.mega-dropdown-menu > li ul > li > a:focus {
  text-decoration: none;
  color:#E61D25!important;
}
.mega-dropdown-menu > li > ul > li > a :hover{}
.mega-dropdown-menu .dropdown-header {
  font-size:15px;
  color: #333;
   font-family: 'RobotoRegular';
  padding: 5px 60px 5px 0px;
  line-height: 20px;
      margin-left: 0px;
}
.mega-dropdown-menu .dropdown-header :hover{
  color:#E61D25!important;
}
.dropdown-menu .divider {
    height: 1px;
    margin: 2px 0;
    overflow: hidden;
    background-color: #fff;
}
@media (min-width: 1570px){
	.mega-dropdown-menu {
    margin-left: -469px;   
}
.container1{
	max-width:1200px;
	
}
@media screen and (min-width:1200px) and (max-width:1499px){
.mega-dropdown-menu {
    margin-left: -304px;  
}	
}
@media screen and (min-width:992px) and (max-width:1199px){
.mega-dropdown-menu {
    margin-left: -430px!important; 
	width: 957px;	
}	
}
</style>
<!-----*************************************** STYLE MEGHA MENU ENDS move to style.css************************---->