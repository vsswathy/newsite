<?
$mainheading="Contact US";
?>
<? include ("itop.php") ?>
<!-------------------------------------++++++++++++++++++------------------------------------>
<!------------------------------------ INNER BANNER START ----------------------------------->
<!-------------------------------------++++++++++++++++++------------------------------------>
<div class="row fluid0">
 <div class="col-12 fluid0">
  <? include ("innerbanner.php") ?>
 </div>
</div>
<!------------------------------------+++++++++++++++++++------------------------------------->
<!------------------------------------ INNER BANNER ENDS ------------------------------------->
<!------------------------------------+++++++++++++++++++------------------------------------->
<div class="container-fluid fluid0 bodywhite py-4" >
 <div id="contactus">
  <div class="container container0">
   <div class="col-12">
    <h2 class="thead"><?echo $mainheading?></h2>
   </div>
   <div class="row mx-0 px-0">	
    <div class="col-12 col-lg-4 fluid0 border-lg-right-dotted">
	 <div class="col-12 pr-lg-5">
      <h3 class="taddressh">COMPANY NAME</h3>
      <address>
       <div class="col-12 fluid0 ">
		<font class="taddress">
		 PO BOX : 00000<br>
		 Address Line1,<br>
		 Address Line2,<br><br>						
		</font>
		<table width="100%">
		 <tr>
		  <td  width="10%" class="taddress">Phone</td><td width="5%" class="taddress" >:</td>
		  <td width="50%"class="taddress">+971 1 111 222</td>
         </tr>
         <tr>		  
          <td width="10%" class="taddress">Email</td><td width="5%" class="taddress">:</td>
          <td width="50%" ><a class="taddress" href="mailto:support@ciber.ae?subject=Enquiry from www.ciber.ae">support@ciber.ae</a></td>
         </tr>	
         <tr>
          <td width="10%"class="taddress">Web</td><td width="5%" class="taddress">:</td>
          <td width="50%" ><a href="http://www.ciber.ae" target="_blank" class="taddress">www.ciber.ae</a></td>
         </tr>
		</table><br>
       </div>		  
      </address>	
      <!----------------+++++++++++++++++++++++++------------------------------------------------------>	   
	  <!---------------- GOOGLE LOCATION MAP START ---------------------------------------------------->
	  <!-----------------++++++++++++++++++++++++------------------------------------------------------>
      <div class="col-12 fluid0" id="qrcode">
       <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d15243983.007440738!2d72.94921925!3d21.125497999999993!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sin!4v1530592604306" width="100%" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
      </div>
	  <!-----------------+++++++++++++++++++++++++---------------------------------------------------->
	  <!---------------- GOOGLE LOCATION MAP ENDS ---------------------------------------------------->   
	  <!----------------++++++++++++++++++++++++++---------------------------------------------------->
     </div>
	</div>
	 
		<?php 
		if( isset($_POST['submit'])) {
		if( $_SESSION['security_code'] == $_POST['security_code'] && !empty($_SESSION['security_code'] ) ) { 
		   /*if( $_POST['security_code']) {//if captcha matches */
		include("contactusform3.php");
		unset($_SESSION['security_code']);
		 } else {//if captha not match
		?>
		<?
		$scriptname=  $_SERVER['SCRIPT_NAME'];
		$spscriptname=preg_split('[/]',$scriptname); 
		$arrno=count($spscriptname);
		$arr=$arrno-1;
		$fname= $spscriptname[$arr]; 
		include("contactusform2.php");
		}}else {//if page accessed for fist time ?>
		<?
		$scriptname=  $_SERVER['SCRIPT_NAME'];
		$spscriptname=preg_split('[/]',$scriptname); 
		$arrno=count($spscriptname);
		$arr=$arrno-1;
		$fname= $spscriptname[$arr];
		include("contactusform.php");
		} ?>
		
   </div>
  </div>
 </div>
</div>
<? include ("ibottom.php") ?>