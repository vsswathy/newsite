<div class="col-12 col-lg-8 pl-lg-5 pt-4 pt-lg-0">
<?
	$name=$_POST["name"];
	$company=$_POST["company"];
	$address=$_POST["address"];
	$city=$_POST["city"];
	$country=$_POST["country"];
	$phone=$_POST["phone"];
	$mobile=$_POST["mobile"];
	$fax=$_POST["fax"];
	$email=$_POST["email"];
	$url=$_POST["url"];
	$requirements=$_POST["requirements"];
?>

<?
$body="<div align='left'><table width='840' height='10' cellspacing='0' cellpadding='0' border='0'bgcolor='white'><tr><td width='840' height='35'></td></tr></table></div>" ;

$body.="<div align='left'><table width='840' height='10' cellspacing='0' cellpadding='0' border='0'bgcolor='white'><tr><td width='840' height='35'><div align='left'><table width='800' height='10' cellspacing='0' cellpadding='0' border='0'>" ;
$body.="<tr><td width='800' height='10' valign='top'  align='left' style='font-size: 24px; font-family : verdana; color: #0C0C0C;'>Thanks for Enquiry ".$name."!</td></tr>" ;

$body.="<tr><td width='800' height='15'></td></tr>" ;
/*remove ciber and add company full name*/
$body.="<tr><td width='800' height='10' valign='top'  align='left' style='font-size: 12px; font-family : verdana; color: #2D2D2D; line-height: 23px;'>Congratulations! <br>You have successfully submitted your enquiry form for ciber </td></tr>" ;
$body.="<tr><td width='800' height='15'></td></tr></table></div></td></tr></table></div>" ;

$body.="<div align='left'><table width='840' height='10' cellspacing='0' cellpadding='0' border='0'bgcolor='white'><tr>" ;
$body.=" <td width='840' height='35'> <div align='left'><table width='840' height='10' cellspacing='0' cellpadding='0' border='0'>" ;
$body.="<tr><td width='840' height='30' style='background-color: #ffffff;   border-style: dotted; border-color: #b1ae8b; border-width:0px;'><div align='left'><table width='700' height='10' cellspacing='0' cellpadding='0' border='0'>" ;
$body.="<tr><td width='700' height='25' valign='top' colspan='2' align='left' style='font-size: 16px; font-family : verdana; color: #000000;'><b>Here is your Enquiry details : </b></td></tr>" ;
$body.="<tr><td width='700' height='10' valign='top' colspan='2'></td></tr>" ;

$body.="<tr><td width='100' height='25' valign='top'  align='left' style='font-size: 12px; font-family : verdana; color: #0C0C0C;'><b>Name  </b></td>" ;
$body.="<td width='350' height='25' valign='top'  align='left' style='font-size: 12px; font-family : verdana; color: #0C0C0C;'>: ".$name."</td></tr>" ;

$body.="<tr><td width='100' height='25' valign='top'  align='left' style='font-size: 12px; font-family : verdana; color: #0C0C0C;'><b>Company </b></td>" ;
$body.="<td width='350' height='25' valign='top'  align='left' style='font-size: 12px; font-family : verdana; color: #0C0C0C;'>: ".$company."</td></tr>" ;

$body.="<tr><td width='100' height='25' valign='top'  align='left' style='font-size: 12px; font-family : verdana; color: #0C0C0C;'><b>Address </b></td>" ;
$body.="<td width='350' height='25' valign='top'  align='left' style='font-size: 12px; font-family : verdana; color: #0C0C0C;'>: ".$address."</td></tr>" ;

$body.="<tr><td width='100' height='25' valign='top'  align='left' style='font-size: 12px; font-family : verdana; color: #0C0C0C;'><b>City </b></td>" ;
$body.="<td width='350' height='25' valign='top'  align='left' style='font-size: 12px; font-family : verdana; color: #0C0C0C;'>: ".$city."</td></tr>" ;

$body.="<tr><td width='100' height='25' valign='top'  align='left' style='font-size: 12px; font-family : verdana; color: #0C0C0C;'><b>Country </b></td>" ;
$body.="<td width='350' height='25' valign='top'  align='left' style='font-size: 12px; font-family : verdana; color: #0C0C0C;'>: ".$country."</td></tr>" ;

$body.="<tr><td width='100' height='25' valign='top'  align='left' style='font-size: 12px; font-family : verdana; color: #0C0C0C;'><b>Phone </b></td>" ;
$body.="<td width='350' height='25' valign='top'  align='left' style='font-size: 12px; font-family : verdana; color: #0C0C0C;'>: ".$phone."</td></tr>" ;

$body.="<tr><td width='100' height='25' valign='top'  align='left' style='font-size: 12px; font-family : verdana; color: #0C0C0C;'><b>Email </b></td>" ;
$body.="<td width='350' height='25' valign='top'  align='left' style='font-size: 12px; font-family : verdana; color: #0C0C0C;'>: ".$email."</td></tr>" ;

$body.="<tr><td width='60' height='25' valign='top'  align='left' style='font-size: 12px; font-family : verdana; color: #0C0C0C;'><b>Requirements</b></td>" ;
$body.="<td width='500' height='25' valign='top'  align='left' style='font-size: 12px; font-family : verdana; color: #0C0C0C;'>: ".$requirements."</td></tr>" ;

/*remove ciber and add company full name*/
$body.="<tr><td width='800' height='10' colspan='2' style='font-size: 12px; font-family : verdana; color: #2D2D2D; line-height: 23px;'><br><b>Thanking you,<br>Team - ciber.</b></td></tr></table></div></td></tr></table></div> </td></tr></table></div>" ;
?>
<?//echo $body;?>

<?php
$flayera="callus.jpg";
require("class.phpmailer.php");
$mail = new PHPMailer();
$mail->IsHTML(true);
$mail->Mailer = "sendmail";
$mail->Host = "127.0.0.1";
$mail->FromName = $name;
$mail->From = $email;
$mail->AddAddress("support2@ciber.ae");

$mail->AddCC($email);
/*remove www.ciber.ae and add company webaddress*/
$mail->Subject = "Enquiry from www.ciber.ae - ".$name;
$mail->AddEmbeddedImage($flayera, "my-attach", $flayera);
$mail->WordWrap = 50;
$mail->Body = $body;

if(!$mail->Send())
{
echo "Message was not sent";
echo "Mailer Error: " . $mail->ErrorInfo;
}
else
{
	
}
?> 
	
 <div class="col-12 fluid0">
  <font class="txtpara">Thank you. <br>Your mail has been successfully submitted. Our Executive will get back to you within 24 hours.</font>
 </div>	
</div>