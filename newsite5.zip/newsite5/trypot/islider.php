
<script>
 $('.carousel').carousel();
</script>
<!------------------------------- ********************************** ------------------------------------->
<!------------------------------- HOME BANNER FOR LARGE SCREEN START ------------------------------------->
<!------------------------------- ********************************** ------------------------------------->
<div id="carouselExampleIndicators" class="carousel slide carousel-fade d-none d-lg-block " data-ride="carousel" data-pause="false">
<!-------------- HOME BANNER CONTROLS SET1 START ------------>
 <ol class="carousel-indicators ">
  <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
  <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
  <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
 </ol>
<!-------------- HOME BANNER CONTROLS SET1 ENDS --------------> 
 <div class="carousel-inner">
  <div class="carousel-item active">
   <img class="d-block w-100" src="webimg/hbanner01.jpg" alt="First slide">
  </div>
  <div class="carousel-item">
   <img class="d-block w-100" src="webimg/hbanner02.jpg" alt="Second slide">
  </div>
  <div class="carousel-item">
   <img class="d-block w-100" src="webimg/hbanner03.jpg" alt="Third slide">
  </div>
 </div>
<!-------------- HOME BANNER CONTROLS SET2 START ------------>  
 <a class="carousel-control-prev " href="#carouselExampleIndicators" role="button" data-slide="prev">
  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
  <span class="sr-only">Previous</span>
 </a>
 <a class="carousel-control-next " href="#carouselExampleIndicators" role="button" data-slide="next">
  <span class="carousel-control-next-icon" aria-hidden="true"></span>
  <span class="sr-only">Next</span>
 </a>
<!-------------- HOME BANNER CONTROLS SET2 ENDS ------------>
</div>
<!------------------------------- ********************************** ------------------------------------>
<!------------------------------- HOME BANNER FOR LARGE SCREEN ENDS ------------------------------------->
<!------------------------------- ********************************** ------------------------------------>
<!------------------------------- ================================== ------------------------------------>
<!------------------------------- ++++++++++++++++++++++++++++++++++ ------------------------------------>
<!------------------------------- HOME BANNER FOR SMALL SCREEN START ------------------------------------>
<!------------------------------- ++++++++++++++++++++++++++++++++++ ------------------------------------>
<div id="carouselExampleIndicators" class="swiper-container  slide carousel-fade d-block d-lg-none" data-pause="false" data-ride="carousel"> 
 <div class="swiper-wrapper">
  <div class="swiper-slide active">
   <img class="d-block w-100" src="webimg/hbanner01.jpg" alt="First slide">
  </div>
  <div class="swiper-slide">
   <img class="d-block w-100" src="webimg/hbanner02.jpg" alt="second slide">
  </div>
  <div class="swiper-slide">
   <img class="d-block w-100" src="webimg/hbanner03.jpg" alt="third slide">
  </div>
  <div class="swiper-slide">
   <img class="d-block w-100" src="webimg/hbanner04.jpg" alt="fourth slide">
  </div>
 </div>
</div>
<!------------------------------- ++++++++++++++++++++++++++++++++++ ------------------------------------>
<!------------------------------- HOME BANNER FOR SMALL SCREEN ENDS ------------------------------------->
<!------------------------------- ++++++++++++++++++++++++++++++++++ ------------------------------------>
<!------script for mobile sliders------------->
<script>
    var swiper = new Swiper('.swiper-container', {
      slidesPerView: 1,
      spaceBetween: 30,
      loop: true,
	   autoplay: {
        delay: 2000,
        disableOnInteraction: false,
      },
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
    });
	
	 
  </script>
  <!------script for mobile sliders------------->
