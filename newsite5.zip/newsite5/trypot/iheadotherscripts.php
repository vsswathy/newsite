<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
<!-------------------------------+++++++++++++++++++++++++++++++++------------------------------------------>
<!-------------------------------SCRIPT FOR MOBLIE MENU LINK START------------------------------------------>
<!-------------------------------+++++++++++++++++++++++++++++++++------------------------------------------>
<link rel="stylesheet" type="text/css" href="mobnav/hamburgers.min.css">
<script type="text/javascript" src="http://code.jquery.com/jquery-3.2.1.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/jQuery.mmenu/7.0.0/jquery.mmenu.all.css">
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jQuery.mmenu/7.0.0/jquery.mmenu.all.js"></script>
<link rel="stylesheet" type="text/css" href="mobnav/jquery.mhead.css"><!--not important-->
<script type="text/javascript" src="mobnav/jquery.mhead.js"></script>
<link rel="stylesheet" href="css/swiper.min.css">
 <script src="js/swiper.min.js"></script>
<!-------------------------------+++++++++++++++++++++++++++++++++------------------------------------------>
<!------------------------------- SCRIPT FOR MOBLIE MENU LINK ENDS------------------------------------------>
<!-------------------------------+++++++++++++++++++++++++++++++++------------------------------------------>