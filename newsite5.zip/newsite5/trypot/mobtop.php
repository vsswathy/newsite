<script type="text/javascript">
$(function() {
 //	create a menu
 $('#menu').mmenu();
 //	fire the plugin
 $('.mh-head.first').mhead({
  scroll: false
 });
 $('.mh-head.second').mhead({
  scroll: {
   hide: 200
  }
 });	
});
</script>
<div class="mh-head first pr-0">
 <span class="mh-btns-left ">
  <a class="mh-hamburger" href="#menu"></a>
 </span>
<!-------------------------- *************************** --------------------------->
<!-------------------------- LOGO FOR SMALL SCREEN START --------------------------->
<!-------------------------- *************************** --------------------------->

 <span class="mh-text"><img src="webimg/logo.jpg" class="img-fluid moblogo"></span>
 
<!------------------------- ************************** ---------------------------->
<!------------------------- LOGO FOR SMALL SCREEN ENDS ----------------------------->
<!------------------------- ************************** ------------------------------>
</div>
<nav id="menu">
 <ul>
  <li><a href="#/">Home</a></li>
  <li><span>About us</span>
   <ul>
    <li><a href="#/about/history">History</a></li>
    <li><span>The team</span>
     <ul>
      <li><a href="#/about/team/management">Management</a></li>
      <li><a href="#/about/team/sales">Sales</a></li>
      <li><a href="#/about/team/development">Development</a></li>
     </ul>
    </li>
    <li><a href="#/about/address">Our address</a></li>
   </ul>
  </li>
  <li><a href="#/contact">Contact</a></li>
 </ul>
</nav>		