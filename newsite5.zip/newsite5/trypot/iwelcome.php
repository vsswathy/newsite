<div class="container-fluid fluid0 bg-white welcomebackgroundimg">
 <div class="container ">
  <div class="row px-0 mx-0">   
   <div class="col-12 col-md-4 text-left mx-0 py-md-5 py-2 pl-0">
    <h1 class="theadi ">Welcome to BSN
     </h1>  
   </div> 
    <div class="text-left col-12 col-md-8 mx-0 py-md-5 py-2 pl-md-3 px-0 ">    
     <p class="txtparai">BSN is a leading organisation, in the United Arab Emirates, rendering quality services in the areas of Equipment Inspection, Safety Consultancy, Trainings and Quality Certification. Our organisation believe in ‘Happy People Happy Customer’ and our service delivery model is developed with focus on People & Customer integration. The ‘Service Delivery’ methodology is defined with clear focus on ‘Quality Services’ and ‘Customer Happiness’. The delivery mechanism ensures that we completely adhere to local authority regulations and international standards/best practices.</p>
   </div>    
  </div>
 </div>
</div>