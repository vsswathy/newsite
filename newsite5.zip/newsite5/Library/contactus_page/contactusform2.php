<div class="col-12 col-lg-8  pl-lg-5 pt-4 pt-lg-0"> 
 <form class="form-horizontal " role="form" autocomplete="off" action="contactus.php" method="post" name="myform" enctype="multipart/form-data" onsubmit="return(validate());">
  <font class="txtpara">
   Please fill in the form below to provide us your company information and your requirements.<br> 
   Kindly fill in all the fields. <!--We will get back to you soon.--><br/>
  </font>
  <br>
  <font class="txtpara">
   Fields marked with<font class="tred"><b> * </b></font>are compulsory
  </font>
  <br><br>  
	<div class="form-group row mx-0 px-0">	
	  <label class="col-12 col-sm-3 col-xl-2 col-form-label fluid0 text-sm-right">
	   <font class="tred">* </font>
	   <font class="txtpara">
	   Name<span style="margin-left:10px;margin-right:10px;">:</span> 
	   </font>
	  </label>
	  <div class="col-12 col-sm-9 col-xl-10 pt-1 pt-sm-0 px-0">
	   <input class="form-control" type="text" value="<? echo $_POST["name"];?>" name="name" autofocus required/>
	  </div>
	</div>
	<div class="form-group row mx-0 px-0">	
	  <label class="col-12 col-sm-3 col-xl-2 col-form-label fluid0 text-sm-right">	  
	   <font class="txtpara">
	   Company<span style="margin-left:10px;margin-right:10px;">:</span> 
	   </font>
	  </label>
	  <div class="col-12 col-sm-9 col-xl-10 pt-1 pt-sm-0 px-0">
	   <input class="form-control" type="text" value="<? echo $_POST["company"];?>" name="company">
	  </div>
	</div>
	<div class="form-group row mx-0 px-0">	
	  <label class="col-12 col-sm-3 col-xl-2 col-form-label fluid0 text-sm-right">	  
	   <font class="txtpara">
	   Address<span style="margin-left:10px;margin-right:10px;">:</span> 
	   </font>
	  </label>
	  <div class="col-12 col-sm-9 col-xl-10 pt-1 pt-sm-0 px-0">
	   <textarea class="form-control" rows="3" value="<? echo $_POST["address"];?>" name="address"></textarea>
	  </div>
	</div>
	<div class="form-group row mx-0 px-0">	
	  <label class="col-12 col-sm-3 col-xl-2 col-form-label fluid0 text-sm-right">	  
	   <font class="txtpara">
	   City<span style="margin-left:10px;margin-right:10px;">:</span> 
	   </font>
	  </label>
	  <div class="col-12 col-sm-9 col-xl-10 pt-1 pt-sm-0 px-0">
	   <input class="form-control" type="text" value="<? echo $_POST["city"];?>" name="city">
	  </div>
	</div>
	<div class="form-group row mx-0 px-0">	
	  <label class="col-12 col-sm-3 col-xl-2 col-form-label fluid0 text-sm-right">	  
	   <font class="txtpara">
	   Country<span style="margin-left:10px;margin-right:10px;">:</span> 
	   </font>
	  </label>
	  <div class="col-12 col-sm-9  col-xl-10 pt-1 pt-sm-0 px-0">
	   <input class="form-control" type="text" value="<? echo $_POST["country"];?>" name="country">
	  </div>
	</div> 
	<div class="form-group row mx-0 px-0">	
	  <label class="col-12 col-sm-3 col-xl-2 col-form-label fluid0 text-sm-right">
	   <font class="tred">* </font>
	   <font class="txtpara">
	   Phone<span style="margin-left:10px;margin-right:10px;">:</span> 
	   </font>
	  </label>
	  <div class="col-12 col-sm-9  col-xl-10 pt-1 pt-sm-0 px-0">
	   <input class="form-control" type="text" value="<? echo $_POST["phone"];?>" name="phone" required/>
	  </div>
	</div> 
	<div class="form-group row mx-0 px-0">	
	  <label class="col-12 col-sm-3 col-xl-2 col-form-label fluid0 text-sm-right">
	   <font class="tred">* </font>
	   <font class="txtpara">
	   Email<span style="margin-left:10px;margin-right:10px;">:</span> 
	   </font>
	  </label>
	  <div class="col-12 col-sm-9  col-xl-10 pt-1 pt-sm-0 px-0">
	    <input class="form-control" type="email" value="<? echo $_POST["email"];?>" name="email" required/>
	  </div>
	</div> 
	<div class="form-group row mx-0 px-0">	
	  <label class="col-12 col-sm-3 col-xl-2 col-form-label fluid0 text-sm-right">	  
	   <font class="txtpara">
	   Requirements<span style="margin-left:10px;margin-right:10px;">:</span> 
	   </font>
	  </label>
	  <div class="col-12 col-sm-9  col-xl-10 pt-1 pt-sm-0 px-0">
	   <textarea class="form-control" rows="3" value="<? echo $_POST["requirements"];?>" name="requirements"></textarea>
	  </div>
	</div> 			
	<div class="form-group row mx-0 px-0" id="sec1">
	 <label class="col-12 col-sm-3 col-xl-2 col-form-label fluid0 text-sm-right">
	   <font class="tred">* </font>
	   <font class="txtpara">
	   Enter Code<span style="margin-left:10px;margin-right:10px;">:</span> 
	   </font>
	  </label>	   
	  <div class="col-4 col-sm-2  col-lg-2 pt-1 pt-sm-0 px-0">
	   <img class="captcha img-fluid" src="CaptchaSecurityImages.php?width=100&height=40&characters=5">
	  </div>
	  <div class="col-8 col-sm-7  col-xl-8 pt-1 pt-sm-0 px-0">
	   <input id="secn" class="form-control"  type="text" name="security_code" required/>
	  </div>
	</div>
   <div class="form-group row mx-0  float-right">
	<button type="submit" class="btn button mr-3 btn-lg hvr-sweep-to-right">Submit</button>
	<button type="reset" class="btn button btn-lg hvr-sweep-to-right">Reset</button>
   </div>  
 </form>
</div>