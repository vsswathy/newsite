<link rel="stylesheet" href="css/jquerysctipttop.css">
<script src="js/jquery.imageslider.js"></script>
<script>
 $(function() {
  $('.js-imageslider').imageslider({
   slideItems: '.my-slider-item',
   slideContainer: '.my-slider-list',
   slideDistance: 1,
   slideDuratin:500,
   resizable: false,
   pause: true
  });
 });
</script>