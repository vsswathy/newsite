<!-- //////////////////////////////////////////////// -->
<!-- REQUIRED ELEMENTS -->
<script src="light_box/lib/jquery.js" type="text/javascript"></script>
<script src="light_box/js/lc_lightbox.lite.js" type="text/javascript"></script>
<link rel="stylesheet" href="light_box/css/lc_lightbox.css" />
<!-- SKINS -->
<link rel="stylesheet" href="light_box/skins/minimal.css" />
<!-- ASSETS -->
<script src="light_box/lib/AlloyFinger/alloy_finger.min.js" type="text/javascript"></script>
<!-- //////////////////////////////////////////////// -->
<!-- //////////////////////////////////////////////// -->
<!-- LIGHTBOX INITIALIZATION -->
<script type="text/javascript">
$(document).ready(function(e) {  
	// live handler
	lc_lightbox('.elem', {
		wrap_class: 'lcl_fade_oc',
		gallery : true,	
		thumb_attr: 'data-lcl-thumb', 
		skin: 'minimal',
		radius: 0,
		padding	: 0,
		border_w: 0,
	});	
});
</script>
<!-- //////////////////////////////////////////////// -->
<!-- JS================================================== -->


<!--------------------------------Image Starts------------------------->
<div class="col-xs-12 fluid0 ">
 <a class="elem" href="webimg/img1.jpg"  data-lcl-thumb="webimg/img1.jpg">
 <img src="webimg/img1.jpg" class="img-responsive"></a>							
</div>
<!--------------------------------Image Ends------------------------->
